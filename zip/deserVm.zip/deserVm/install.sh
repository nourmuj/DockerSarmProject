#!/usr/bin/env bash




#Delete Nodejs
apt-get purge --auto-remove  nodejs
apt-get purge nodejs
apt-get autoremove
# End of delete Nodejs 

#System initial
apt-get update -y 
apt-get dist-upgrade
apt-get upgrade -y
# End of System_init

#Install apache2
apt-get install apache2 -y
#End of install apache2


#uninstall Docker  
sudo apt-get purge docker-ce
sudo rm -rf /var/lib/docker 
#end of remove Docker


#insntall docker
sudo apt-get update

sudo apt-get install \ apt-transport-https \ ca-certificates \  curl \  gnupg2 \  software-properties-common

curl -fsSL https://download.docker.com/linux/debian/gpg | sudo apt-key add -

sudo apt-key fingerprint 0EBFCD88

sudo add-apt-repository \   "deb [arch=amd64] https://download.docker.com/linux/debian \   $(lsb_release -cs) \   stable"

sudo apt-get update

sudo apt-get install docker-ce
#End of docker installation



#Install Nodejs
curl -sL https://deb.nodesource.com/setup_10.x | sudo -E bash -
sudo apt-get install -y nodejs
sudo apt-get install -y build-essential
#End of Install Nodejs 


#Install keepass2
apt-get install keepass2 -y
#end of instal keepass2


#add user and add this user  to docker group

sudo useradd -m userdocker -p lassmich 
sudo usermod -a -G docker userdocker
#end of add section


#given Permitions  and setup Cornjob
chown -R www-data:www-data /var/www/html/
touch /var/spool/cron/crontabs/root
echo '@reboot cd /var/www/html/ &&  /usr/bin/node  /var/www/html/server.js' >> /var/spool/cron/crontabs/root

#End of section


#install Nodejs Vuln_Lib node-serialize(version 0.0.4)
cd /var/www/html
rm package-lock.json
rm -R node_modules
npm install
npm install node-serialize@0.0.4
npm install express
npm install cookie-parser
npm install escape-html
npm install ejs --save
npm start
#End of install requirments





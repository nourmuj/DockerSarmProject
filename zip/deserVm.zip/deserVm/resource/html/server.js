var express = require('express');
var cookieParser = require('cookie-parser');
var escape = require('escape-html');
var serialize = require('node-serialize');
var app = express();

app.set('view engine', 'ejs')

app.use(cookieParser())
app.get('/', function(req, res) {
  if (req.cookies.profile) {
    var str = new Buffer(req.cookies.profile,'base64').toString();
    var obj = serialize.unserialize(str);
 if (obj.username) {
    res.send('Hello ' + escape(obj.username));
}

} else {

res.cookie('profile',"eyJ1c2VybmFtZSI6ImdhbWVyIiwiY291bnRyeSI6Imdlcm1hbnkiLCJjaXR5Ijoia29lbG4ifQ==", { maxAge: 900000, httpOnly: true});
}
res.render('index');

});



app.listen(3000);

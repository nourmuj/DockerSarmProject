var express = require('express');
var app = express();
var fs = require ('fs');
var bodyParser = require('body-parser');

app.set('view engine', 'ejs')
app.use(express.static(__dirname + '/public'));


app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies


app.get('/', function(req, res) {
	res.render('index');

});


app.get('/AZazTfsF123Rtdfjh9O0', function (req, res) {
       res.render('AZazTfsF123Rtdfjh9O0');
});


app.post('/inputForm', function (req, res) {

	var resp=eval("("+req.body.input+")");
 	res.send('Your Input was: </br>'+resp);


});




app.listen(8001, function() {
  console.log('Server running at http://127.0.0.1:8001/');
});



#!/usr/bin/env bash

# The script fails if a single command returns a non-zero exit value
set -e
set -o pipefail
export DEBIAN_FRONTEND="noninteractive"

apt-get -y update



#Downloading depences and vulnerable Nginx
wget http://ftp.psu.ru/linux/debian-security/pool/updates/main/n/nginx/nginx-common_1.6.2-5+deb8u2_all.deb
dpkg -i  nginx-common_1.6.2-5+deb8u2_all.deb
wget http://ftp.psu.ru/linux/debian-security/pool/updates/main/n/nginx/nginx-full_1.6.2-5+deb8u2_amd64.deb 
dpkg -i nginx-full_1.6.2-5+deb8u2_amd64.deb
wget http://ftp.psu.ru/linux/debian-security/pool/updates/main/n/nginx/nginx_1.6.2-5+deb8u2_all.deb
dpkg -i nginx_1.6.2-5+deb8u2_all.deb
#Ende of Download

#Stoping new Version of nginx and install depences
echo "nginx hold" | sudo dpkg --set-selections
echo "nginx-common hold" | sudo dpkg --set-selections
echo "nginx-full hold" | sudo dpkg --set-selections

apt install  -y -f 
apt-get install -y  gcc
#Ende of Installing depences 

#dpkg -i  nginx-common_1.6.2-5+deb8u2_all.deb
#dpkg -i nginx-full_1.6.2-5+deb8u2_amd64.deb
#dpkg -i nginx_1.6.2-5+deb8u2_all.deb

#Restart nginx service
/etc/init.d/nginx restart


#Install nodejs and move the Project files to html folder
curl -sL https://deb.nodesource.com/setup_10.x | sudo -E bash -
sudo apt-get install -y nodejs


cd  /var/www/html
rm  package-lock.json
rm -R node_modules/
npm install 
npm install express
nmp install fs
nmp install body-parser
npm install ejs

#change owner of html folder
cd /var/www/
chown -R www-data:www-data html/


####installing cronjob ####
touch /var/spool/cron/crontabs/root
echo '*/2 * * * *  /usr/sbin/logrotate -f /etc/logrotate.d/nginx'  >> /var/spool/cron/crontabs/root 
echo '@reboot cd /var/www/html/ &&  /usr/bin/node  /var/www/html/server.js' >> /var/spool/cron/crontabs/root

# The above lines sets permissions to 744 - this is permissive: cron refuses to execute this
chown root:root /var/spool/cron/crontabs/root
chmod 600 /var/spool/cron/crontabs/root
service cron restart
####end cronjob       ####

